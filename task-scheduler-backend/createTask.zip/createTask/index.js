const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');

const dynamodb = new AWS.DynamoDB.DocumentClient();
const TABLE_NAME = process.env.TABLE_NAME;

exports.handler = async (event) => {
    const body = JSON.parse(event.body);

    const task = {
        task_id: uuidv4(),
        title: body.title,
        due_date: body.due_date,
        type: body.type
    };

    await dynamodb.put({
        TableName: TABLE_NAME,
        Item: task
    }).promise();

    return {
        statusCode: 201,
        body: JSON.stringify(task)
    };
};
