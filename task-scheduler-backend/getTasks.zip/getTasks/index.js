const AWS = require('aws-sdk');

const dynamodb = new AWS.DynamoDB.DocumentClient();
const TABLE_NAME = process.env.TABLE_NAME;

exports.handler = async (event) => {
    const result = await dynamodb.scan({
        TableName: TABLE_NAME
    }).promise();

    return {
        statusCode: 200,
        body: JSON.stringify(result.Items)
    };
};
